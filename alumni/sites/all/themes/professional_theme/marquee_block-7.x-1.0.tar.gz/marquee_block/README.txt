To use this module, download the jquery marquee plugin from here: 
https://gist.github.com/2484402 
and put it into this module's directory as jquery.marquee.js

This module exposes a block called "Scrolling Marquee" that you can configure 
with custom text or HTML.